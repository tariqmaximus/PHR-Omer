// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
   production: false,
   AppVersion: require('../../package.json').version, // <major>.<minor>.<yymmdd>.<build> | "1.0.250417.1 -- Build No defatul 1. Increment for each build on same date.
   AuthServerEndpoint:'https://apiauth.maximus.care',          
   APIEndpoint: 'https://ehr.maximus.care/pre.prod.maximus/',   
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
